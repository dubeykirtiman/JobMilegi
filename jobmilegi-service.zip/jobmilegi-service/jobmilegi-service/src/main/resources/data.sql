INSERT INTO user (name, email, password, phone_number, address, created_at)
VALUES 
('John Doe', 'john@example.com', 'password123', '1234567890', '123 Main Street', NOW());
