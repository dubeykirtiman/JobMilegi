package com.jobmilegi.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobmilegiApplicationTests {

    @Test
    void contextLoads() {
        // Test if the Spring Boot context loads correctly
    }
}
